package com.example.voiceassistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

/**
 * Gemini Live (WebSocket) से लगातार आवाज़ वाली बातचीत:
 * माइक की आवाज़ सीधे भेजता है, जवाब की आवाज़ (24kHz) तुरंत बजाता है, बीच में टोकने पर रुक जाता है,
 * और फ़ोन के काम "फ़ंक्शन कॉल" से करवाता है।
 */
class LiveEngine(
    private val ctx: Context,
    private val runner: ActionRunner,
    private val cb: Callbacks
) {
    interface Callbacks {
        fun status(s: String)
        fun saveTurn(user: String, model: String)
        fun systemText(): String
        fun onFailure(msg: String)
        fun onEmptySession()
        fun forget()
        fun ensureLoud()
    }

    companion object {
        const val WS = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
        const val FALLBACK_MODEL = "gemini-3.1-flash-live-preview"
        const val IDLE_MS = 25_000L

        @Volatile private var resolved: String? = null

        /** सेटिंग में नाम हो तो वही, वरना key से उपलब्ध Live मॉडलों में सबसे नया चुनो */
        fun resolveModel(key: String, pref: String): String {
            if (pref.isNotBlank()) return pref.trim().removePrefix("models/")
            resolved?.let { return it }
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
                    .openConnection() as HttpURLConnection
                c.setRequestProperty("x-goog-api-key", key)
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode in 200..299) {
                    val arr = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("models")
                    var best: String? = null
                    var bestScore = -1.0
                    if (arr != null) for (i in 0 until arr.length()) {
                        val m = arr.getJSONObject(i)
                        val name = m.optString("name").removePrefix("models/")
                        val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                        var live = false
                        for (j in 0 until methods.length()) if (methods.getString(j) == "bidiGenerateContent") live = true
                        if (!live || !name.contains("live") || name.contains("transcribe") || name.contains("translate")) continue
                        val ver = Regex("(\\d+(\\.\\d+)?)").find(name)?.value?.toDoubleOrNull() ?: 0.0
                        val score = ver + (if (name.contains("preview")) 0.0 else 0.01)
                        if (score > bestScore) { bestScore = score; best = name }
                    }
                    if (best != null) { resolved = best; return best }
                }
            } catch (_: Exception) { }
            return FALLBACK_MODEL
        }

        private fun prop(name: String, type: String, desc: String) = Triple(name, type, desc)

        private fun fn(name: String, desc: String, vararg props: Triple<String, String, String>,
                       required: List<String> = emptyList()): JSONObject {
            val f = JSONObject().put("name", name).put("description", desc)
            if (props.isNotEmpty()) {
                val p = JSONObject()
                for ((n, t, d) in props) p.put(n, JSONObject().put("type", t).put("description", d))
                val params = JSONObject().put("type", "OBJECT").put("properties", p)
                if (required.isNotEmpty()) params.put("required", JSONArray(required))
                f.put("parameters", params)
            }
            return f
        }

        fun declarations(): JSONArray {
            val to = prop("to", "STRING", "नाम या नंबर, जैसा यूज़र ने बोला")
            val toEn = prop("to_en", "STRING", "वही नाम रोमन (अंग्रेज़ी) अक्षरों में")
            val ok = prop("user_confirmed", "BOOLEAN", "तभी true जब यूज़र ने इसी काम के लिए अभी साफ़ 'हाँ' कहा हो")
            val text = prop("text", "STRING", "संदेश का टेक्स्ट, यूज़र के बोले शब्दों में")
            val a = JSONArray()
            a.put(fn("alarm", "अलार्म लगाओ", prop("hour", "INTEGER", "24 घंटे में घंटा"), prop("minute", "INTEGER", "मिनट"),
                prop("label", "STRING", "नाम/लेबल"), required = listOf("hour", "minute")))
            a.put(fn("timer", "टाइमर लगाओ", prop("seconds", "INTEGER", "सेकंड"), required = listOf("seconds")))
            a.put(fn("call", "किसी को फ़ोन कॉल करो (पहले यूज़र से पूछो)", to, toEn, ok, required = listOf("to")))
            a.put(fn("sms", "SMS भेजो (पहले यूज़र से पूछो)", to, toEn, text, ok, required = listOf("to", "text")))
            a.put(fn("whatsapp", "व्हाट्सऐप संदेश भेजो (पहले यूज़र से पूछो)", to, toEn, text, ok, required = listOf("to", "text")))
            a.put(fn("contact", "किसी का फ़ोन नंबर बताओ", to, toEn, required = listOf("to")))
            a.put(fn("play_music", "गाना बजाओ", prop("query", "STRING", "गाने या कलाकार का नाम"), required = listOf("query")))
            a.put(fn("media", "चल रहे संगीत/वीडियो को कंट्रोल करो", prop("cmd", "STRING", "pause, play, next, previous, stop"), required = listOf("cmd")))
            a.put(fn("open_app", "कोई ऐप खोलो", prop("name", "STRING", "ऐप का अंग्रेज़ी नाम, जैसे YouTube"), required = listOf("name")))
            a.put(fn("flashlight", "टॉर्च चालू/बंद करो", prop("on", "BOOLEAN", "true = चालू")))
            a.put(fn("volume", "आवाज़ बदलो", prop("dir", "STRING", "up, down, mute, max"), prop("level", "INTEGER", "0 से 100")))
            a.put(fn("maps", "नक्शे में रास्ता/जगह दिखाओ", prop("query", "STRING", "जगह का नाम"), required = listOf("query")))
            a.put(fn("settings", "फ़ोन की सेटिंग का पेज खोलो", prop("page", "STRING", "wifi, bluetooth, airplane, location, display, sound, battery")))
            a.put(fn("calendar", "कैलेंडर के कार्यक्रम पढ़ो", prop("days", "INTEGER", "कितने दिन")))
            a.put(fn("notifications", "हाल के नोटिफ़िकेशन/नए मैसेज पढ़ो", prop("app", "STRING", "वैकल्पिक: ऐप का नाम, जैसे WhatsApp")))
            a.put(fn("navigate", "फ़ोन में नेविगेट करो (एक्सेसिबिलिटी चाहिए)",
                prop("where", "STRING", "back, home, recents, notifications, quick_settings, lock, screenshot"), required = listOf("where")))
            a.put(fn("click", "स्क्रीन पर दिखते शब्द/बटन पर टैप करो", prop("text", "STRING", "स्क्रीन पर दिखता शब्द"), required = listOf("text")))
            a.put(fn("scroll", "स्क्रीन स्क्रॉल करो", prop("dir", "STRING", "down या up")))
            a.put(fn("type", "चुनी हुई जगह में टेक्स्ट लिखो", prop("text", "STRING", "टेक्स्ट"), required = listOf("text")))
            a.put(fn("look", "तस्वीर देखो: फ़ोन की स्क्रीन या कैमरा", prop("source", "STRING", "screen, front (सेल्फ़ी कैमरा), back (पीछे का कैमरा)"),
                prop("question", "STRING", "यूज़र का सवाल"), required = listOf("source")))
            a.put(fn("note_add", "नोट या लिस्ट में कुछ जोड़ो", prop("text", "STRING", "क्या जोड़ना है"), prop("list", "STRING", "लिस्ट का नाम, जैसे शॉपिंग"),
                required = listOf("text")))
            a.put(fn("note_read", "नोट या लिस्ट पढ़ो", prop("list", "STRING", "लिस्ट का नाम")))
            a.put(fn("note_clear", "नोट या लिस्ट साफ़ करो", prop("list", "STRING", "लिस्ट का नाम")))
            a.put(fn("remember", "यूज़र के बारे में कोई बात हमेशा के लिए याद रखो", prop("fact", "STRING", "याद रखने वाली बात"), required = listOf("fact")))
            a.put(fn("forget", "पुरानी बातचीत भूल जाओ"))
            return a
        }

        fun setupJson(model: String, voice: String, system: String, search: Boolean): JSONObject {
            val gen = JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))))
            val tools = JSONArray()
            if (search) tools.put(JSONObject().put("googleSearch", JSONObject()))
            tools.put(JSONObject().put("functionDeclarations", declarations()))
            val setup = JSONObject()
                .put("model", "models/$model")
                .put("generationConfig", gen)
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("tools", tools)
                .put("inputAudioTranscription", JSONObject())
                .put("outputAudioTranscription", JSONObject())
            return JSONObject().put("setup", setup)
        }

        /** सेटिंग की key से Live कनेक्शन आज़माकर नतीजा बताता है (बैकग्राउंड थ्रेड से बुलाएँ) */
        fun test(ctx: Context): String {
            val cfg = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
            val key = cfg.getString("api_key", "")?.trim().orEmpty()
            if (key.isEmpty()) return "पहले API key डालकर सेव करें"
            val model = resolveModel(key, cfg.getString("live_model", "") ?: "")
            val voice = cfg.getString("live_voice", "")?.trim().orEmpty().ifEmpty { "Kore" }
            val sb = StringBuilder("मॉडल: $model\n")
            for (search in listOf(true, false)) {
                val latch = CountDownLatch(1)
                val outcome = AtomicReference("")
                val client = OkHttpClient()
                val ws = client.newWebSocket(Request.Builder().url("$WS?key=$key").build(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        webSocket.send(setupJson(model, voice, "यह सिर्फ़ एक परीक्षण है।", search).toString())
                    }
                    override fun onMessage(webSocket: WebSocket, text: String) {
                        if (text.contains("setupComplete")) { outcome.compareAndSet("", "✅ चल रहा है"); latch.countDown() }
                    }
                    override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                        if (bytes.utf8().contains("setupComplete")) { outcome.compareAndSet("", "✅ चल रहा है"); latch.countDown() }
                    }
                    override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                        outcome.compareAndSet("", "❌ $code ${reason.take(120)}"); latch.countDown()
                    }
                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        outcome.compareAndSet("", "❌ ${(t.message ?: t.javaClass.simpleName).take(120)} ${response?.code ?: ""}")
                        latch.countDown()
                    }
                })
                latch.await(10, TimeUnit.SECONDS)
                try { ws.close(1000, "test") } catch (_: Exception) { }
                client.dispatcher.executorService.shutdown()
                val o = outcome.get().ifEmpty { "❌ समय ख़त्म" }
                sb.append(if (search) "Search के साथ: " else "बिना Search: ").append(o).append('\n')
                if (o.startsWith("✅")) break
            }
            return sb.toString().trim()
        }
    }

    // ---------------- स्थिति ----------------
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private val exec = Executors.newSingleThreadExecutor()
    private val pendingMsgs = ArrayList<String>()
    private val curUser = StringBuilder()
    private val curModel = StringBuilder()
    private val playQ = LinkedBlockingQueue<ByteArray>()

    @Volatile private var ws: WebSocket? = null
    @Volatile private var currentListener: Listener? = null
    @Volatile private var ready = false
    @Volatile private var connecting = false
    @Volatile private var searchOk = true
    @Volatile private var meaningful = false
    @Volatile private var destroyed = false
    @Volatile private var lastActivity = 0L
    @Volatile private var speakingUntil = 0L
    @Volatile private var lastYesAt = 0L
    @Volatile private var askedAt = 0L
    @Volatile private var track: AudioTrack? = null
    @Volatile private var playThread: Thread? = null

    private fun prefs() = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun isOpen() = ws != null || connecting
    fun isSpeaking() = System.currentTimeMillis() < speakingUntil + 400
    fun touch() { lastActivity = System.currentTimeMillis() }

    // ---------------- कनेक्शन ----------------
    fun ensureSession() {
        if (ws != null || connecting || destroyed) return
        val key = prefs().getString("api_key", "")?.trim().orEmpty()
        if (key.isEmpty()) { cb.onFailure("API key नहीं है"); return }
        connecting = true; ready = false; meaningful = false
        touch()
        thread {
            try {
                val model = resolveModel(key, prefs().getString("live_model", "") ?: "")
                val voice = prefs().getString("live_voice", "")?.trim().orEmpty().ifEmpty { "Kore" }
                val search = searchOk && prefs().getBoolean("use_search", true)
                val l = Listener(model, voice, search)
                currentListener = l
                ws = client.newWebSocket(Request.Builder().url("$WS?key=$key").build(), l)
            } catch (e: Exception) {
                connecting = false
                cb.onFailure(e.message ?: "कनेक्शन नहीं बना")
            }
        }
    }

    private inner class Listener(val model: String, val voice: String, val search: Boolean) : WebSocketListener() {
        @Volatile var intentional = false
        override fun onOpen(webSocket: WebSocket, response: Response) {
            webSocket.send(setupJson(model, voice, cb.systemText(), search).toString())
        }
        override fun onMessage(webSocket: WebSocket, text: String) { handle(this, text) }
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) { handle(this, bytes.utf8()) }
        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            try { webSocket.close(code, reason) } catch (_: Exception) { }
            lost(this, code, reason)
        }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { lost(this, code, reason) }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            lost(this, -1, t.message ?: t.javaClass.simpleName)
        }
    }

    private fun lost(l: Listener, code: Int, reason: String) {
        if (l !== currentListener) return
        val wasReady = ready
        reset(keepPending = !wasReady && l.search && searchOk)
        if (l.intentional || wasReady) return
        if (l.search && searchOk) {              // शायद Search के साथ न चले: बिना Search फिर कोशिश
            searchOk = false
            ensureSession()
            return
        }
        synchronized(pendingMsgs) { pendingMsgs.clear() }
        cb.onFailure("$code ${reason.take(100)}".trim())
    }

    private fun reset(keepPending: Boolean) {
        ws = null; ready = false; connecting = false
        currentListener = null
        if (!keepPending) synchronized(pendingMsgs) { pendingMsgs.clear() }
        flushPlayback()
    }

    fun close() {
        val w = ws
        if (w == null && !connecting) return
        currentListener?.intentional = true
        finishTurn()
        try { w?.close(1000, "idle") } catch (_: Exception) { }
        reset(keepPending = false)
    }

    fun release() {
        destroyed = true
        close()
        exec.shutdownNow()
    }

    /** काफ़ी देर से कोई बातचीत नहीं हुई तो सेशन बंद करो (खर्च बचाने के लिए) */
    fun tick() {
        if (ws != null && ready && !isSpeaking() && System.currentTimeMillis() - lastActivity > IDLE_MS) {
            val had = meaningful
            close()
            if (!had) cb.onEmptySession()
            cb.status("लाइव: आराम में (बोलते ही फिर चालू)")
        }
    }

    // ---------------- भेजना ----------------
    fun sendMic(chunk: ShortArray, n: Int) {
        val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) bb.putShort(chunk[i])
        val b64 = Base64.encodeToString(bb.array(), Base64.NO_WRAP)
        val msg = "{\"realtimeInput\":{\"audio\":{\"data\":\"$b64\",\"mimeType\":\"audio/pcm;rate=16000\"}}}"
        if (ready) ws?.send(msg)
        else synchronized(pendingMsgs) { if (pendingMsgs.size < 40) pendingMsgs.add(msg) }
    }

    private fun sendImage(jpeg: ByteArray) {
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        ws?.send("{\"realtimeInput\":{\"video\":{\"data\":\"$b64\",\"mimeType\":\"image/jpeg\"}}}")
    }

    // ---------------- आना ----------------
    private fun handle(l: Listener, text: String) {
        if (l !== currentListener) return
        val o = try { JSONObject(text) } catch (e: Exception) { return }
        if (o.has("setupComplete")) {
            ready = true; connecting = false
            cb.status("लाइव चालू 🎙")
            val w = ws
            synchronized(pendingMsgs) { for (m in pendingMsgs) w?.send(m); pendingMsgs.clear() }
            return
        }
        o.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) flushPlayback()
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                    val d = inl?.optString("data").orEmpty()
                    if (d.isNotEmpty()) {
                        meaningful = true; touch()
                        enqueue(Base64.decode(d, Base64.DEFAULT))
                    }
                }
            }
            sc.optJSONObject("inputTranscription")?.optString("text")?.let { t ->
                if (t.isNotEmpty()) {
                    meaningful = true; touch()
                    curUser.append(t)
                    cb.status("सुना: " + curUser.toString().takeLast(70))
                    noteYesNo(t)
                }
            }
            sc.optJSONObject("outputTranscription")?.optString("text")?.let { t ->
                if (t.isNotEmpty()) { touch(); curModel.append(t) }
            }
            if (sc.optBoolean("turnComplete")) finishTurn()
        }
        o.optJSONObject("toolCall")?.let { handleToolCall(it) }
        if (o.has("goAway")) cb.status("लाइव सेशन जल्द ख़त्म होगा, अगली बात पर अपने-आप नया खुलेगा")
    }

    private fun noteYesNo(t: String) {
        val tokens = t.lowercase().split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }
        if (tokens.any { it in AssistantService.NO }) { lastYesAt = 0L; return }
        if (tokens.any { it in AssistantService.YES }) lastYesAt = System.currentTimeMillis()
    }

    private fun finishTurn() {
        val u = curUser.toString().trim()
        val m = curModel.toString().trim()
        curUser.setLength(0); curModel.setLength(0)
        if (u.isNotEmpty() && m.isNotEmpty()) cb.saveTurn(u, m)
    }

    // ---------------- फ़ंक्शन कॉल (फ़ोन के काम) ----------------
    private fun handleToolCall(tc: JSONObject) {
        val calls = tc.optJSONArray("functionCalls") ?: return
        exec.execute {
            val responses = JSONArray()
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                val name = c.optString("name")
                val args = c.optJSONObject("args") ?: JSONObject()
                val result = try { runTool(name, args) } catch (e: Exception) { "यह काम नहीं हो पाया" }
                responses.put(JSONObject().put("id", c.optString("id")).put("name", name)
                    .put("response", JSONObject().put("result", result)))
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", responses)).toString())
        }
    }

    private fun runTool(name: String, args: JSONObject): String {
        if (name == "forget") { cb.forget(); return "पुरानी बातचीत मिटा दी" }
        if (name == "look") {
            val src = args.optString("source", "screen")
            val q = args.optString("question")
            val jpeg: ByteArray? = when (src) {
                "front" -> CameraGrab.capture(ctx, true)
                "back" -> CameraGrab.capture(ctx, false)
                else -> PhoneControlService.instance?.screenshotJpeg()
            }
            if (jpeg == null) return if (src == "screen")
                (if (PhoneControlService.instance == null) "स्क्रीन देखने के लिए एक्सेसिबिलिटी चालू नहीं है" else "स्क्रीन की तस्वीर नहीं मिल पाई")
            else "कैमरा नहीं खुल पाया, कैमरे की इजाज़त चेक करें"
            sendImage(jpeg)
            return "तस्वीर भेज दी है। अब उसे देखकर यूज़र के सवाल का जवाब दो: $q"
        }
        val a = JSONObject(args.toString()).put("type", name)
        if (runner.needsConfirm(a)) {            // सुरक्षा: कॉल/SMS/व्हाट्सऐप सिर्फ़ यूज़र की साफ़ 'हाँ' के बाद
            val now = System.currentTimeMillis()
            val ok = args.optBoolean("user_confirmed") && lastYesAt > askedAt && now - lastYesAt < 30_000
            if (!ok) {
                askedAt = now
                return "रुको, अभी भेजा/किया नहीं गया। पहले यूज़र से साफ़ पूछो: " + runner.describe(a) +
                    " और उसके 'हाँ' कहने पर ही यही फ़ंक्शन user_confirmed=true के साथ दोबारा बुलाओ।"
            }
            lastYesAt = 0L
        }
        return runner.run(a) ?: "हो गया"
    }

    // ---------------- जवाब की आवाज़ बजाना ----------------
    private fun enqueue(b: ByteArray) {
        ensurePlayback()
        val now = System.currentTimeMillis()
        if (now >= speakingUntil) cb.ensureLoud()
        speakingUntil = maxOf(now, speakingUntil) + b.size / 2 * 1000L / 24000
        playQ.offer(b)
    }

    private fun ensurePlayback() {
        if (playThread != null) return
        synchronized(this) {
            if (playThread != null) return
            val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setSampleRate(24000)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(min, 24000))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            t.play()
            track = t
            playThread = thread(name = "live-play") {
                try {
                    while (!destroyed) {
                        val b = playQ.poll(500, TimeUnit.MILLISECONDS) ?: continue
                        track?.write(b, 0, b.size)
                    }
                } catch (_: Exception) {
                } finally {
                    try { t.stop(); t.release() } catch (_: Exception) { }
                }
            }
        }
    }

    /** बीच में टोकने पर तुरंत चुप: बजने की कतार खाली करो */
    fun flushPlayback() {
        playQ.clear()
        try { track?.pause(); track?.flush(); track?.play() } catch (_: Exception) { }
        speakingUntil = 0L
    }

    fun bargeIn() = flushPlayback()
}
