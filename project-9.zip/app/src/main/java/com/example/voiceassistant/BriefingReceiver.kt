package com.example.voiceassistant

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** रोज़ तय समय पर सुबह की ब्रीफ़िंग शुरू करता है */
class BriefingReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, i: Intent?) {
        schedule(ctx)                         // अगले दिन के लिए फिर तय करो
        val svc = AssistantService.instance
        if (svc != null) svc.runBriefing()
        else {                                // सर्विस बंद है: नोटिफ़िकेशन से याद दिलाओ
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("brief", "Briefing", NotificationManager.IMPORTANCE_DEFAULT))
            nm.notify(2, android.app.Notification.Builder(ctx, "brief")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("सुबह की ब्रीफ़िंग")
                .setContentText("सुनने के लिए Karan assistant में \"सुनना शुरू करें\" दबाएँ")
                .setAutoCancel(true).build())
        }
    }

    companion object {
        /** सेटिंग के "HH:MM" के हिसाब से अगला अलार्म लगाओ (खाली हो तो रद्द) */
        fun schedule(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val pi = PendingIntent.getBroadcast(ctx, 7, Intent(ctx, BriefingReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val t = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
                .getString("brief_time", "")?.trim().orEmpty()
            val m = Regex("^(\\d{1,2})[:.](\\d{2})$").find(t)
            if (m == null) { am.cancel(pi); return }
            val h = m.groupValues[1].toInt(); val mi = m.groupValues[2].toInt()
            if (h > 23 || mi > 59) { am.cancel(pi); return }
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, mi); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis() + 5000) add(Calendar.DAY_OF_YEAR, 1)
            }
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }
}
