package com.example.voiceassistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import kotlin.math.sqrt

class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_TOGGLE = "toggle_game_mode"
        const val CHANNEL = "assistant"
        const val MAX_HISTORY = 20
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
        const val SR = 16000
        @Volatile var instance: AssistantService? = null
        const val AMBIENT_GAP = 60_000L   // आसपास पर राय देने के बीच कम से कम इतना समय
        val YES = setOf("हाँ", "हां", "हा", "हाँजी", "yes", "yeah", "ok", "okay", "ठीक", "जी",
            "भेज", "भेजो", "करो", "कर")
        val NO = setOf("नहीं", "नही", "no", "cancel", "रद्द", "मत", "रुको", "stop")
    }

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("mem", MODE_PRIVATE) }
    private val runner by lazy { ActionRunner(this) }
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = true
    @Volatile private var paused = false   // गेम मोड
    @Volatile private var busy = false     // सोच/बोल रहा हो तो माइक की आवाज़ अनदेखी
    @Volatile private var working = false  // फ़ोन के काम चल रहे हैं
    @Volatile private var blockedUntil = 0L // Gemini की लिमिट लगने पर इस समय तक कॉल नहीं
    @Volatile private var awakeUntil = 0L   // इस समय तक बिना नाम लिए भी बात कर सकते हैं
    @Volatile private var extendWindow = false
    @Volatile private var lastAmbientAt = 0L
    @Volatile private var busySince = 0L
    @Volatile private var lastSpoken = ""          // अपनी आख़िरी बात (अपनी गूँज पहचानने के लिए)
    @Volatile private var thinkLevel = "MINIMAL"
    private val CONTROL_RE = Regex("^(सुना|आसपास|मालिक|ACTION|LIVE)\\s*[:：]")
    private val actionExec = Executors.newSingleThreadExecutor()   // काम क्रम से, तुरंत चलें
    private val jobs = AtomicInteger(0)
    private var engine: LiveEngine? = null              // Gemini Live (लगातार बातचीत)
    @Volatile private var liveFailedUntil = 0L          // Live न चले तो इस समय तक सामान्य मोड
    @Volatile private var liveCooldownUntil = 0L        // खाली सेशन के बाद थोड़ा रुकना
    @Volatile private var autoPaused = false            // गेम खुलने पर अपने-आप रुका
    private var fgPkg: String? = null
    private var lastUsageQuery = 0L
    private var liveNoise = 300.0
    private var liveLastLoud = 0L
    private var liveGateOpen = false
    private val liveRing = ArrayDeque<ShortArray>()
    private val gameRunnable = object : Runnable {
        override fun run() {
            try { pollGame() } catch (_: Exception) { }
            handler.postDelayed(this, 3000)
        }
    }
    @Volatile private var ownerAuthUntil = 0L      // इस समय तक मालिक पहचाना हुआ माना जाएगा
    @Volatile private var liveFrame: ByteArray? = null
    @Volatile private var liveFrameAt = 0L
    @Volatile private var frameJobAt = 0L
    @Volatile private var lastDenyAt = 0L
    private val ownerFile by lazy { java.io.File(filesDir, "owner.jpg") }
    private var status = "सुन रहा हूँ 🎤"

    @Volatile private var pending: List<JSONObject>? = null   // हाँ/नहीं का इंतज़ार करता काम
    @Volatile private var pendingAt = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Assistant", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (Build.VERSION.SDK_INT >= 30 &&
                checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            startForeground(1, n, type)
        } else startForeground(1, n)

        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dhakad:listen").apply { acquire() }

        tts = TextToSpeech(this, this)
        instance = this
        engine = LiveEngine(this, runner, object : LiveEngine.Callbacks {
            override fun status(s: String) { setStatus(s) }
            override fun saveTurn(user: String, model: String) { this@AssistantService.saveTurn(user, model) }
            override fun systemText(): String = liveSystemText()
            override fun onFailure(msg: String) {
                liveFailedUntil = System.currentTimeMillis() + 120_000
                setStatus("लाइव नहीं चला ($msg), सामान्य मोड चालू")
            }
            override fun onEmptySession() { liveCooldownUntil = System.currentTimeMillis() + 30_000 }
            override fun forget() { prefs.edit().remove("h").apply() }
            override fun ensureLoud() { handler.post { this@AssistantService.ensureLoud() } }
        })
        handler.postDelayed(gameRunnable, 3000)
        BriefingReceiver.schedule(this)
        startAudioLoop()
        warmUp()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TOGGLE) {
            paused = !paused
            setStatus(if (paused) "गेम मोड: रुका हुआ" else "सुन रहा हूँ 🎤")
        }
        return START_STICKY
    }

    // ---------- नोटिफ़िकेशन ----------
    private fun buildNotification(): Notification {
        val pi = PendingIntent.getService(
            this, 0,
            Intent(this, AssistantService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause),
            if (paused) "सुनना शुरू करें" else "गेम मोड (रोकें)", pi).build()
        return Notification.Builder(this, CHANNEL)
            .setContentTitle(if (paused || autoPaused) "गेम मोड: असिस्टेंट रुका है" else "Karan assistant चालू है")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(action)
            .setOngoing(true)
            .build()
    }

    private fun setStatus(s: String) {
        status = s
        handler.post {
            getSystemService(NotificationManager::class.java).notify(1, buildNotification())
        }
    }

    // ---------- आवाज़ (TTS) ----------
    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) {
            setStatus("बोलने वाला इंजन नहीं चला: Google Text-to-speech इंस्टॉल करें")
            return
        }
        val r = tts.setLanguage(Locale("hi", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            tts.setLanguage(Locale.getDefault())
        tts.setSpeechRate(1.1f)   // थोड़ा तेज़ बोलना
        tts.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { listenSoon() }
            override fun onError(id: String?) { listenSoon() }
        })
        ttsReady = true
    }

    /** लाइन की शुरुआत में "टैग:" हो तो टैग के बाद का हिस्सा लौटाता है (जैसे "सुना : xyz" भी चलेगा) */
    private fun tagOf(line: String, tag: String): String? =
        Regex("^\\s*" + tag + "\\s*[:：]\\s*(.*)$").find(line)?.groupValues?.get(1)

    /** बोलने से पहले markdown, इमोजी, लिंक जैसी चीज़ें हटाओ ताकि आवाज़ साफ़ और सलीकेदार रहे */
    private fun cleanForSpeech(src: String): String {
        var t = src
        t = Regex("https?://\\S+").replace(t, "")
        t = Regex("[*#_`~>|\\[\\]{}]").replace(t, "")
        t = Regex("[\\p{So}\\p{Cs}\\uFE0F]").replace(t, "")
        t = Regex("\\s+").replace(t, " ").trim()
        return if (t.length > 400) t.take(400) else t
    }

    private val speakParams = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f) }

    private fun setBusy() { busy = true; busySince = System.currentTimeMillis() }

    /** जवाब की आवाज़ तेज़ रखने के लिए मीडिया वॉल्यूम कम हो तो 90% तक बढ़ाओ */
    private fun ensureLoud() {
        try {
            if (!getSharedPreferences("settings", MODE_PRIVATE).getBoolean("loud", true)) return
            val am = getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val want = (max * 0.9).toInt()
            if (am.getStreamVolume(AudioManager.STREAM_MUSIC) < want)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, want, 0)
        } catch (_: Exception) { }
    }

    /** धीमी रिकॉर्डिंग को सॉफ़्टवेयर से ज़ोर देकर (अधिकतम 8 गुना) साफ़ सुनने लायक बनाओ */
    private fun boost(pcm: ByteArray): ByteArray {
        val n = pcm.size / 2
        if (n == 0) return pcm
        val bb = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        var peak = 1
        for (i in 0 until n) { val v = Math.abs(bb.getShort(i * 2).toInt()); if (v > peak) peak = v }
        val gain = minOf(8.0, 22000.0 / peak)
        if (gain <= 1.05) return pcm
        val out = ByteBuffer.allocate(pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n)
            out.putShort((bb.getShort(i * 2) * gain).toInt().coerceIn(-32768, 32767).toShort())
        return out.array()
    }

    private fun say(msg0: String, flush: Boolean = true) {
        val msg = cleanForSpeech(msg0)
        if (msg.isEmpty()) { handler.post { listenSoon() }; return }
        lastSpoken = (lastSpoken + " " + msg).takeLast(300)
        handler.post {
            setBusy()
            ensureLoud()
            val mode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            if (ttsReady && tts.speak(msg, mode, speakParams, "u" + System.nanoTime()) == TextToSpeech.SUCCESS)
                return@post
            listenSoon()
        }
    }

    /** बोलना/काम ख़त्म होने के थोड़ी देर बाद फिर सुनना शुरू (अपनी ही आवाज़ न पकड़े) */
    private fun listenSoon() {
        handler.postDelayed({
            if (working || (ttsReady && tts.isSpeaking)) listenSoon()
            else {
                busy = false
                if (extendWindow) {                   // जवाब के बाद 12 सेकंड बिना नाम के बात कर सकते हैं
                    awakeUntil = System.currentTimeMillis() + 12_000
                    extendWindow = false
                }
                setStatus(if (paused) "गेम मोड: रुका हुआ" else "सुन रहा हूँ 🎤")
            }
        }, 800)
    }

    // ---------- माइक सुनना (VAD) ----------
    @SuppressLint("MissingPermission")
    private fun startAudioLoop() {
        thread(name = "audio-loop") {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            val minBuf = AudioRecord.getMinBufferSize(
                SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val liveOnStart = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("live_mode", true)
            val srcMic = if (liveOnStart) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
            val rec = try {
                AudioRecord(srcMic, SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, SR * 2))
            } catch (e: Exception) {
                setStatus("माइक नहीं खुला: परमिशन चेक करें"); return@thread
            }
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                setStatus("माइक की परमिशन/एक्सेस नहीं मिली"); return@thread
            }

            try {                                  // माइक की हल्की आवाज़ अपने-आप बढ़ाओ
                if (AutomaticGainControl.isAvailable())
                    AutomaticGainControl.create(rec.audioSessionId)?.setEnabled(true)
            } catch (_: Exception) { }
            try {                                  // गूँज हटाओ (लाइव में बीच में टोकने के लिए ज़रूरी)
                if (AcousticEchoCanceler.isAvailable())
                    AcousticEchoCanceler.create(rec.audioSessionId)?.setEnabled(true)
            } catch (_: Exception) { }

            val chunk = ShortArray(1600)           // 100 ms
            val buf = ByteArrayOutputStream()
            val preroll = ArrayDeque<ShortArray>()
            var recording = false
            var inSpeech = false
            var loudRun = 0
            var loudTotal = 0
            var quiet = 0
            var noise = 300.0

            try {
                while (running) {
                    if (paused || autoPaused) {     // गेम मोड: माइक पूरी तरह छोड़ दो
                        engine?.close()
                        if (recording) { rec.stop(); recording = false }
                        inSpeech = false; buf.reset(); preroll.clear(); loudRun = 0
                        Thread.sleep(300); continue
                    }
                    if (!recording) { rec.startRecording(); recording = true }

                    val n = rec.read(chunk, 0, chunk.size)
                    if (n < 0) {                    // माइक किसी और ने ले लिया, फिर कोशिश
                        try { rec.stop() } catch (_: Exception) {}
                        recording = false; Thread.sleep(500); continue
                    }
                    if (n == 0) { Thread.sleep(50); continue }
                    if (liveEnabled()) {            // लाइव मोड: आवाज़ सीधे Gemini Live को
                        liveStep(chunk, n)
                        inSpeech = false; buf.reset(); preroll.clear(); loudRun = 0
                        continue
                    } else if (engine?.isOpen() == true) engine?.close()
                    if (busy) {                     // सोच/बोल रहा है, आवाज़ अनदेखी
                        // कहीं अटक गया हो (जैसे बोलना ख़त्म होने का संकेत न आया) तो 25 सेकंड बाद छोड़ दो
                        if (!working && System.currentTimeMillis() - busySince > 25_000 &&
                            !(ttsReady && tts.isSpeaking)) busy = false
                        inSpeech = false; buf.reset(); preroll.clear(); loudRun = 0
                        continue
                    }

                    var sum = 0.0
                    for (i in 0 until n) sum += chunk[i].toDouble() * chunk[i]
                    val rms = sqrt(sum / n)
                    // सिर्फ़ पास की, आसपास के स्तर से तेज़ आवाज़ गिनो (दूर की टीवी/लोगों की आवाज़ नहीं)
                    val loud = rms > maxOf(250.0, noise * 1.5)   // संवेदनशील: हल्की और दूर की आवाज़ भी पकड़ो

                    if (!inSpeech) {
                        noise = noise * 0.97 + rms * 0.03     // आसपास का औसत स्तर (लगातार टीवी भी इसमें आ जाती है)
                        preroll.addLast(chunk.copyOf(n))
                        if (preroll.size > 4) preroll.removeFirst()
                        loudRun = if (loud) loudRun + 1 else 0
                        if (loudRun >= 2) {         // बोलना शुरू हुआ
                            inSpeech = true; quiet = 0; loudTotal = loudRun
                            for (c in preroll) writeShorts(buf, c)
                            preroll.clear()
                            if (ownerNeeded()) startFrameCapture()   // बोलते-बोलते कैमरे से फ़्रेम ले लो
                        }
                    } else {
                        writeShorts(buf, chunk.copyOf(n))
                        if (loud) { quiet = 0; loudTotal++ } else quiet++
                        if (quiet >= (if (buf.size() < SR * 2 * 3) 5 else 8) || buf.size() > SR * 2 * 15) {   // 0.7 सेकंड चुप्पी / 15 सेकंड पूरे
                            val pcm = buf.toByteArray()
                            buf.reset(); inSpeech = false; loudRun = 0
                            if (loudTotal >= 3 && System.currentTimeMillis() >= blockedUntil) {   // छोटी आवाज़ और लिमिट के समय अनदेखी
                                setBusy()
                                setStatus("सोच रहा हूँ…")
                                thread(priority = Thread.MIN_PRIORITY) { processAudio(pcm) }
                            }
                            loudTotal = 0
                        }
                    }
                }
            } catch (e: Exception) {
                setStatus("माइक एरर: ${e.javaClass.simpleName}")
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
            }
        }
    }

    private fun writeShorts(out: ByteArrayOutputStream, s: ShortArray) {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in s) bb.putShort(v)
        out.write(bb.array())
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16)
        h.putShort(1); h.putShort(1); h.putInt(SR); h.putInt(SR * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(pcm.size)
        return h.array() + pcm
    }

    // ---------- याददाश्त ----------
    private fun turn(role: String, text: String) = JSONObject().put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun loadHistory(): JSONArray =
        try { JSONArray(prefs.getString("h", "[]")) } catch (e: Exception) { JSONArray() }

    private fun saveTurn(user: String, model: String) {
        val hist = loadHistory()
        hist.put(turn("user", user)).put(turn("model", model))
        val trimmed = JSONArray()
        for (i in maxOf(0, hist.length() - MAX_HISTORY) until hist.length()) trimmed.put(hist.get(i))
        prefs.edit().putString("h", trimmed.toString()).apply()
    }

    // ---------- लाइव मोड (Gemini Live) ----------
    private fun liveEnabled(): Boolean =
        engine != null &&
            getSharedPreferences("settings", MODE_PRIVATE).getBoolean("live_mode", true) &&
            System.currentTimeMillis() >= liveFailedUntil

    /** माइक के हर टुकड़े पर: आवाज़ हो तो Live को भेजो, बाकी समय चुप रहो (खर्च बचाने के लिए) */
    private fun liveStep(chunk: ShortArray, n: Int) {
        val eng = engine ?: return
        var sum = 0.0
        for (i in 0 until n) sum += chunk[i].toDouble() * chunk[i]
        val rms = sqrt(sum / n)
        val barge = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("barge", true)
        val speaking = eng.isSpeaking()
        val now = System.currentTimeMillis()
        liveRing.addLast(chunk.copyOf(n))
        if (liveRing.size > 3) liveRing.removeFirst()
        if (speaking && !barge) { liveGateOpen = false; eng.tick(); return }   // आधा-डुप्लेक्स: बोलते समय माइक बंद
        val thr = if (speaking) maxOf(900.0, liveNoise * 2.5) else maxOf(300.0, liveNoise * 1.6)
        val loud = rms > thr
        liveNoise = if (loud) liveNoise * 0.995 + rms * 0.005 else liveNoise * 0.97 + rms * 0.03
        if (loud) liveLastLoud = now
        if (loud || now - liveLastLoud < 1800) {         // बात के बाद 1.8 सेकंड तक भेजो ताकि सर्वर को चुप्पी सुनाई दे
            if (!eng.isOpen()) {
                if (now < liveCooldownUntil) { liveGateOpen = false; return }
                eng.ensureSession()
            }
            if (!liveGateOpen) {
                liveGateOpen = true
                if (speaking && loud) eng.bargeIn()      // बीच में टोका: तुरंत चुप
                for (c in liveRing) eng.sendMic(c, c.size)
            } else eng.sendMic(chunk, n)
        } else liveGateOpen = false
        eng.tick()
    }

    private fun factsText(): String {
        val f = ActionRunner.facts(this)
        return if (f.isEmpty()) "" else "यूज़र के बारे में याद रखी बातें: " + f.joinToString("; ")
    }

    private fun recentText(): String {
        val h = loadHistory()
        val sb = StringBuilder()
        for (i in maxOf(0, h.length() - 6) until h.length()) {
            val o = h.getJSONObject(i)
            val who = if (o.optString("role") == "user") "यूज़र" else "तुम"
            val t = o.optJSONArray("parts")?.optJSONObject(0)?.optString("text").orEmpty()
            if (t.isNotBlank()) sb.append(who).append(": ").append(t.take(160)).append('\n')
        }
        return sb.toString().trim()
    }

    private fun liveSystemText(): String {
        val cfg = getSharedPreferences("settings", MODE_PRIVATE)
        val city = cfg.getString("city", "")?.trim().orEmpty()
        val nick = cfg.getString("nick", "")?.trim().orEmpty().ifEmpty { "भाई" }
        return systemPrompt(city, false, false, cfg.getBoolean("use_search", true), nick, false, voice = true)
    }

    // ---------- गेम अपने-आप पहचानना ----------
    private fun isGamePkg(pkg: String): Boolean = try {
        val info = packageManager.getApplicationInfo(pkg, 0)
        info.category == ApplicationInfo.CATEGORY_GAME || (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    } catch (e: Exception) { false }

    private fun pollGame() {
        val cfg = getSharedPreferences("settings", MODE_PRIVATE)
        if (!cfg.getBoolean("auto_game", true)) {
            if (autoPaused) { autoPaused = false; setStatus("सुन रहा हूँ 🎤") }
            return
        }
        val ops = getSystemService(AppOpsManager::class.java)
        val mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        if (mode != AppOpsManager.MODE_ALLOWED) return          // Usage access की इजाज़त नहीं
        val usm = getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val from = if (lastUsageQuery == 0L) now - 60_000 else lastUsageQuery
        lastUsageQuery = now
        val ev = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> fgPkg = e.packageName
                UsageEvents.Event.ACTIVITY_PAUSED -> if (fgPkg == e.packageName) fgPkg = null
            }
        }
        val pkg = fgPkg
        val game = pkg != null && pkg != packageName && isGamePkg(pkg)
        if (game != autoPaused) {
            autoPaused = game
            if (game) engine?.close()
            setStatus(if (game) "गेम मिला: सुनना रुका हुआ" else "सुन रहा हूँ 🎤")
        }
    }

    // ---------- सुबह की ब्रीफ़िंग ----------
    fun runBriefing() {
        thread(priority = Thread.MIN_PRIORITY) {
            try {
                val cfg = getSharedPreferences("settings", MODE_PRIVATE)
                val key = cfg.getString("api_key", "")?.trim().orEmpty()
                if (key.isEmpty()) return@thread
                val model = cfg.getString("model", DEFAULT_MODEL)?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }
                val city = cfg.getString("city", "")?.trim().orEmpty()
                val nick = cfg.getString("nick", "")?.trim().orEmpty().ifEmpty { "भाई" }
                val cal = runner.run(JSONObject().put("type", "calendar").put("days", 1)) ?: ""
                val q = "सुबह की ब्रीफ़िंग दो: (1) ${city.ifEmpty { "मेरे शहर" }} का आज का मौसम, (2) आज की 3 मुख्य खबरें, (3) कैलेंडर की यह जानकारी: $cal। " +
                    "गर्मजोशी से सुप्रभात कहकर शुरू करो, 6-8 छोटे वाक्य, हर वाक्य अलग लाइन में।"
                val contents = JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", q))))
                val sys = systemPrompt(city, false, false, true, nick, false, live = true)
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"
                var said = false
                var r = streamGemini(url, key, buildBody(contents, sys, useThinking, true)) { ln ->
                    val t = ln.trim()
                    if (t.isNotEmpty() && !CONTROL_RE.containsMatchIn(t)) { say(t, flush = !said); said = true }
                }
                if (r.first == 400 || r.first == 429) {
                    r = streamGemini(url, key, buildBody(contents, sys, false, false)) { ln ->
                        val t = ln.trim()
                        if (t.isNotEmpty() && !CONTROL_RE.containsMatchIn(t)) { say(t, flush = !said); said = true }
                    }
                }
                if (r.first !in 200..299) say("ब्रीफ़िंग नहीं ला पाया, एरर कोड ${r.first}")
            } catch (e: Exception) {
                say("ब्रीफ़िंग नहीं ला पाया")
            }
        }
    }

    // ---------- मालिक की पहचान (कैमरा) ----------
    private fun ownerNeeded(): Boolean =
        getSharedPreferences("settings", MODE_PRIVATE).getBoolean("owner_only", false) &&
            ownerFile.exists() && System.currentTimeMillis() >= ownerAuthUntil

    private fun startFrameCapture() {
        val now = System.currentTimeMillis()
        if (now - frameJobAt < 4000) return
        frameJobAt = now
        thread(priority = Thread.MIN_PRIORITY) {
            val j = CameraGrab.capture(this, true)
            liveFrame = j
            liveFrameAt = System.currentTimeMillis()
            if (j == null) setStatus("कैमरा नहीं खुला (मालिक की पहचान नहीं हो सकी)")
        }
    }

    private fun imgPart(b: ByteArray) = JSONObject().put("inline_data", JSONObject()
        .put("mime_type", "image/jpeg").put("data", Base64.encodeToString(b, Base64.NO_WRAP)))

    // ---------- तस्वीर देखना (स्क्रीन / कैमरा) ----------
    private fun submitLook(a: JSONObject) {
        jobs.incrementAndGet(); working = true
        actionExec.execute {
            try {
                val src = a.optString("source", "screen")
                val q = a.optString("question").ifEmpty { "इसमें क्या दिख रहा है?" }
                val jpeg: ByteArray? = when (src) {
                    "front" -> CameraGrab.capture(this, true)
                    "back" -> CameraGrab.capture(this, false)
                    else -> PhoneControlService.instance?.screenshotJpeg()
                }
                if (jpeg == null) {
                    say(if (src == "screen")
                        (if (PhoneControlService.instance == null) "स्क्रीन देखने के लिए पहले एक्सेसिबिलिटी चालू करें"
                         else "स्क्रीन की तस्वीर नहीं मिल पाई")
                        else "कैमरा नहीं खुल पाया, कैमरे की इजाज़त चेक करें", flush = false)
                } else visionAsk(jpeg, q)
            } catch (e: Exception) {
                say("तस्वीर देख नहीं पाया", flush = false)
            } finally {
                if (jobs.decrementAndGet() == 0) {
                    working = false
                    handler.post { listenSoon() }
                }
            }
        }
    }

    private fun visionAsk(jpeg: ByteArray, question: String) {
        val cfg = getSharedPreferences("settings", MODE_PRIVATE)
        val key = cfg.getString("api_key", "")?.trim().orEmpty()
        if (key.isEmpty()) { say("पहले ऐप की सेटिंग में API key डालें", flush = false); return }
        val model = cfg.getString("model", DEFAULT_MODEL)?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }
        val nick = cfg.getString("nick", "")?.trim().orEmpty().ifEmpty { "भाई" }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"
        val system = "तुम यूज़र के सलीकेदार, गर्मजोशी भरे AI साथी हो; उसे '$nick' कहकर बुलाओ और 'आप' से बात करो। दी गई तस्वीर देखकर यूज़र के सवाल का जवाब " +
            "यूज़र की भाषा में 1-3 छोटे वाक्यों में दो, हर वाक्य अलग लाइन में, बिना markdown के। जो दिख रहा है वही बताओ, " +
            "अंदाज़ा हो तो साफ़ कहो। पासवर्ड, OTP, कार्ड नंबर जैसी संवेदनशील चीज़ें बोलकर मत पढ़ना।"
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
            .put(imgPart(jpeg)).put(JSONObject().put("text", question))))
        var r = streamGemini(url, key, buildBody(contents, system, useThinking, false)) { ln ->
            val t = ln.trim()
            if (t.isNotEmpty()) say(t, flush = false)
        }
        if (r.first == 400 && useThinking) {
            useThinking = false
            r = streamGemini(url, key, buildBody(contents, system, false, false)) { ln ->
                val t = ln.trim()
                if (t.isNotEmpty()) say(t, flush = false)
            }
        }
        if (r.first !in 200..299) say("तस्वीर समझ नहीं पाया, एरर कोड ${r.first}", flush = false)
    }

    /** पहली कॉल से पहले ही सर्वर से कनेक्शन खोलकर रखो, ताकि पहली बार धीमा न पड़े */
    private fun warmUp() {
        thread(priority = Thread.MIN_PRIORITY) {
            try {
                val c = URL("https://generativelanguage.googleapis.com/").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                val code = c.responseCode
                (if (code >= 400) c.errorStream else c.inputStream)?.close()
            } catch (_: Exception) { }
        }
    }

    /** ACTION लाइन आते ही काम तुरंत चलाओ (पूरे जवाब का इंतज़ार नहीं) */
    private fun submitAction(a: JSONObject) {
        jobs.incrementAndGet(); working = true
        actionExec.execute {
            try {
                val r = runner.run(a)
                if (r != null) say(r, flush = false)
                Thread.sleep(200)
            } finally {
                if (jobs.decrementAndGet() == 0) {
                    working = false
                    handler.post { listenSoon() }
                }
            }
        }
    }

    // ---------- Gemini (स्ट्रीमिंग: पहला वाक्य आते ही बोलना शुरू) ----------
    @Volatile private var useThinking = true   // "सोचना न्यूनतम" सेटिंग; मॉडल न माने तो अपने-आप बंद

    private fun apiMessage(raw: String): String =
        try { JSONObject(raw).getJSONObject("error").getString("message").take(120) }
        catch (e: Exception) { "" }

    private fun systemPrompt(city: String, wake: Boolean, windowOpen: Boolean, search: Boolean, nick: String, ambient: Boolean, live: Boolean = false, owner: Boolean = false, voice: Boolean = false): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.ENGLISH).format(Date())
        val bat = try {
            getSystemService(BatteryManager::class.java)
                .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) { -1 }
        val a11y = if (PhoneControlService.instance != null) "चालू है" else "बंद है"
        val factsBlock = factsText()
        val ambientRules = "आसपास की आवाज़ें सुनने वाला मोड चालू है। हर ऑडियो के लिए पहले तय करो कि बात तुमसे है या नहीं। " +
            "(क) अगर यूज़र तुमसे बात कर रहा है (सवाल, हुक्म, तुम्हें बुलाना, या तुम्हारी बात का जवाब), तो नीचे वाला 'सुना:' फ़ॉर्मेट रखो। " +
            "(ख) अगर आवाज़ आसपास की है (टीवी, फ़िल्म, समाचार, गाना, या दूसरे लोगों की आपसी बातचीत), तो पहली लाइन में 'आसपास: ' लिखकर " +
            "एक छोटे वाक्य में बताओ कि क्या चल रहा है, फिर अगली लाइन में सिर्फ़ तभी एक छोटी, दोस्ताना राय या टिप्पणी (एक वाक्य) दो " +
            "जब सचमुच कोई बहुत काम की या मज़ेदार बात हो। ज़्यादातर बार कुछ कहना ज़रूरी नहीं होता, तब पूरे जवाब में सिर्फ़ NONE लिखो; राय हमेशा विनम्र और सलीकेदार रखो। " +
            "आसपास की आवाज़ों के आधार पर कोई ACTION कभी मत करो, और किसी का निजी राज़, नंबर या संवेदनशील बात मत दोहराओ। राय सभ्य और संक्षिप्त रखो।"
        val gate0 = when {
            wake && !windowOpen -> "बहुत ज़रूरी: अभी तुम सिर्फ़ तभी जवाब दो जब बोलने वाले ने तुम्हें नाम लेकर बुलाया हो, यानी वाक्य में 'धाकड़' (Dhakad) या 'असिस्टेंट' (Assistant) शब्द हो। नाम नहीं है तो पूरे जवाब में सिर्फ़ NONE लिखो।"
            wake -> "अभी बातचीत चल रही है, इसलिए नाम लिए बिना भी यूज़र की बात का जवाब दो। पर आवाज़ अगर टीवी या दूसरे लोगों की लगे और तुमसे बात न हो रही हो, तो NONE लिखो।"
            else -> "हर साफ़ बोली का जवाब दो, पर अगर लगे कि बात तुमसे नहीं, टीवी या दूसरे लोगों से हो रही है, तो NONE लिखो।"
        } + " टीवी, फ़िल्म, गाने, समाचार, विज्ञापन या आपस में बात करते लोगों की आवाज़ पर कभी जवाब मत दो और कोई काम मत करो।"
        val gate = if (ambient) ambientRules else gate0
        val persona = "तुम एक आवाज़ वाले दोस्ताना AI साथी हो, ChatGPT की वॉइस बातचीत की तरह: गर्मजोशी भरे, स्वाभाविक, समझदार और सलीकेदार। " +
            "यूज़र ही तुम्हारा बॉस और मालिक है; उसे '$nick' कहकर बुलाओ और 'आप' कहकर आदर से बात करो। उसके कहे काम फ़ौरन करो। " +
            "बात करने का तरीका: (1) सहज बोलचाल की हिंदी में बोलो (ज़रूरत हो तो आम हिंग्लिश शब्द चलेंगे), जैसे कोई समझदार दोस्त फ़ोन पर बात कर रहा हो; " +
            "किताबी या रोबोट जैसी भाषा नहीं। (2) जवाब बोलने लायक छोटे वाक्यों में दो: पहले सीधा जवाब, फिर ज़रूरत हो तो एक छोटी काम की बात। लंबा भाषण नहीं। " +
            "(3) यूज़र की बात में सच्ची दिलचस्पी दिखाओ, और मौका हो तो कभी-कभी एक छोटा सा आगे का सवाल पूछो (हर बार नहीं)। " +
            "(4) भावनाएँ समझो: परेशान हो तो पहले हमदर्दी, फिर मदद; खुश हो तो साथ में खुश हो जाओ। " +
            "(5) हल्का-फुल्का मज़ाक कभी-कभी ठीक है, पर कभी किसी का मज़ाक, तंज़, ताना या अपमान नहीं; गाली या बदतमीज़ी तो बिल्कुल नहीं। " +
            "(6) बोलने से पहले सोचो: सही और काम की बात कहो, पक्का न हो तो ईमानदारी से बता दो, हाँ में हाँ मत मिलाओ, कुछ जोखिम भरा लगे तो प्यार से आगाह करो। " +
            "(7) सेहत, पैसे या दुख की बातों में मज़ाक कम और परवाह ज़्यादा। (8) जवाब में markdown, सूची, इमोजी या खास चिह्न मत लिखो, क्योंकि जवाब बोलकर सुनाया जाएगा।"
        val unknown = "जवाब पता न हो तो सिर्फ़ 'मुझे नहीं पता' कभी मत कहो। ऐसे करो: " +
            (if (search) "(1) ताज़ा या लाइव बात हो तो ऊपर बताए अनुसार LIVE लिखो। "
             else "(1) Google Search अभी बंद है; ताज़ा जानकारी के सवाल पर अपनी सबसे अच्छी जानकारी बताओ और एक छोटा वाक्य जोड़ो कि सेटिंग में Search चालू करने पर ताज़ा जवाब मिलेगा। ") +
            "(2) फिर भी पक्का न हो तो अपनी जानकारी के हिसाब से सबसे संभावित जवाब दो और साथ में 'शायद' या 'मेरे हिसाब से' जोड़ दो। " +
            "(3) सवाल अधूरा या साफ़ न हो तो एक छोटा सवाल पूछकर साफ़ करवा लो। " +
            "पर नाम, नंबर, तारीख़ या आँकड़े कभी खुद गढ़कर पक्के तथ्य की तरह मत बताओ; अंदाज़ा हो तो साफ़ कहो कि यह अंदाज़ा है।"
        val ownerRule = if (owner)
            "मालिक की पहचान: इस बार ऑडियो के साथ दो तस्वीरें हैं। इमेज 1 मालिक की रेफ़रेंस फ़ोटो है और इमेज 2 अभी की फ्रंट-कैमरा फ़्रेम है। " +
            "सबसे पहली लाइन में ज़रूर लिखो: 'मालिक: हाँ' अगर इमेज 2 में वही व्यक्ति साफ़ दिख रहा है जो इमेज 1 में है; " +
            "'मालिक: अनजान' अगर कोई दूसरा व्यक्ति दिख रहा है; 'मालिक: कोई नहीं' अगर कैमरे में कोई नहीं दिख रहा या चेहरा साफ़ नहीं है। " +
            "यकीन न हो तो 'अनजान' मानो। 'मालिक: हाँ' न हो तो उस लाइन के बाद कुछ भी मत लिखो। " +
            "'मालिक: हाँ' हो तभी अगली लाइनों में नीचे वाला सामान्य फ़ॉर्मेट (सुना:/आसपास:/NONE) रखो।"
        else ""
        val guard = "सावधानी: अगर ऑडियो में शब्द साफ़ समझ न आएँ तो अंदाज़े से कुछ मत गढ़ो, पूरे जवाब में सिर्फ़ NONE लिखो। " +
            "तुम्हारी अपनी पिछली बात: '" + lastSpoken.takeLast(300) + "'। अगर ऑडियो इससे मिलता-जुलता हो तो वह तुम्हारी अपनी आवाज़ की गूँज है, तब भी सिर्फ़ NONE लिखो।"
        val liveRule = if (search)
            "लाइव जानकारी (मौसम, खबर, स्कोर, भाव, आज-अभी की बात) चाहिए तो 'सुना:' लाइन के बाद सिर्फ़ एक लाइन 'LIVE' लिखकर रुक जाओ; ऐप खुद खोजकर जवाब देगा।"
        else ""
        if (voice) return """
$persona

संदर्भ: अभी का समय $now। फ़ोन की बैटरी $bat%। यूज़र का शहर: ${city.ifEmpty { "पता नहीं" }}। एक्सेसिबिलिटी $a11y।
$factsBlock
पिछली बातचीत (सार):
${recentText()}

आवाज़ वाली बातचीत के नियम:
- हिंदी (या यूज़र की भाषा) में स्वाभाविक, गर्मजोशी भरी बोली में बोलो। जवाब छोटे रखो, जैसे फ़ोन पर बात हो रही हो।
- फ़ोन का कोई काम करवाना हो तो पहले संबंधित फ़ंक्शन बुलाओ, फिर 2-4 शब्द में बताओ क्या किया (जैसे "जी, खोल दिया")।
- कॉल, SMS या व्हाट्सऐप से पहले यूज़र से साफ़ पूछो ("राहुल को मैसेज भेजूँ: ...? हाँ या नहीं?"), और उसके "हाँ" कहने पर ही फ़ंक्शन को user_confirmed=true के साथ बुलाओ।
- मौसम, खबर, स्कोर जैसी ताज़ा जानकारी के लिए Google Search इस्तेमाल करो।
- टीवी, गाने या दूसरे लोगों की आवाज़ पर जवाब मत दो; सिर्फ़ तब बोलो जब बात तुमसे हो रही हो। अपनी ही आवाज़ की गूँज पर जवाब मत दो।
- नाम, नंबर या संदेश कभी खुद मत गढ़ो।
- जवाब पता न हो तो सिर्फ़ "नहीं पता" मत कहो: खोजो, या सबसे संभावित जवाब "शायद" लगाकर दो, या छोटा सा सवाल पूछ लो। अंदाज़े को पक्का तथ्य बनाकर मत बताओ।
- यूज़र बीच में टोके तो तुरंत रुककर उसकी बात सुनो।
- सूची, markdown या खास चिह्न की तरह मत बोलो; बातचीत की तरह बोलो।
- यूज़र किसी बात को "याद रखो" कहे तो remember फ़ंक्शन बुलाओ; नोट्स और लिस्ट के लिए note_add, note_read, note_clear।
""".trimIndent()
        if (live) return """
$persona

$factsBlock

संदर्भ: अभी का समय $now। यूज़र का शहर: ${city.ifEmpty { "पता नहीं" }}।
यूज़र का सवाल टेक्स्ट में है। Google Search से ताज़ा जानकारी देखकर यूज़र की भाषा में 1-3 छोटे वाक्यों में जवाब दो, हर वाक्य अलग लाइन में, बिना markdown के। 'सुना:' या ACTION मत लिखो। जवाब सटीक और संक्षिप्त रखो। पक्का न हो तो साफ़ कहो कि यह अंदाज़ा है, पर सिर्फ़ 'नहीं पता' कहकर मत रुको।
""".trimIndent()
        return """
तुम 'Karan assistant' हो, एक हिंदी वॉइस असिस्टेंट, जिसे धाकड़ ने बनाया है।
संदर्भ: अभी का समय $now। फ़ोन की बैटरी $bat%। यूज़र का शहर: ${city.ifEmpty { "पता नहीं" }}। एक्सेसिबिलिटी $a11y।
$liveRule

$persona

$factsBlock

$ownerRule

$gate

$unknown

$guard

यूज़र की आवाज़ ऑडियो में आती है। जवाब का फ़ॉर्मेट सख़्ती से यह रखो:
1) पहली लाइन: 'सुना: ' के बाद ऑडियो में जो बोला गया उसका सही टेक्स्ट।
2) अगर यूज़र फ़ोन का कोई काम करवा रहा है, तो 'सुना:' लाइन के ठीक बाद पहले ACTION लाइनें लिखो (नीचे सूची है), और उसके बाद सिर्फ़ 2-4 शब्द का जवाब दो, जैसे 'जी, खोल दिया'। बाकी बातों पर यूज़र की भाषा में 1-3 छोटे वाक्यों का जवाब दो, बिना markdown के, हर वाक्य अलग लाइन में। कॉल, SMS या व्हाट्सऐप के काम पर जवाब की लाइन में सिर्फ़ 'ठीक है' लिखो, पुष्टि ऐप खुद पूछेगा।
3) अगर ऑडियो में कोई साफ़ इंसानी बोली नहीं है (शोर, खामोशी, खटपट, टीवी की पृष्ठभूमि), तो पूरे जवाब में सिर्फ़ NONE लिखो।

फ़ोन के काम के लिए 'सुना:' लाइन के ठीक बाद, जवाब से पहले, हर काम की अलग लाइन में ऐसे लिखो (सिर्फ़ तब, जब यूज़र ने साफ़ कहा हो):
ACTION: {"type":"alarm","hour":6,"minute":30,"label":"उठना"}   (hour 24 घंटे में, सुबह/शाम का ध्यान रखो)
ACTION: {"type":"timer","seconds":300}
ACTION: {"type":"call","to":"राहुल","to_en":"Rahul"}   (to: नाम या नंबर जैसा यूज़र ने बोला, to_en: वही नाम रोमन अक्षरों में)
ACTION: {"type":"sms","to":"राहुल","to_en":"Rahul","text":"संदेश"}
ACTION: {"type":"whatsapp","to":"राहुल","to_en":"Rahul","text":"संदेश"}
ACTION: {"type":"contact","to":"राहुल","to_en":"Rahul"}   (किसी का नंबर बताने के लिए)
ACTION: {"type":"play_music","query":"गाने या कलाकार का नाम"}
ACTION: {"type":"media","cmd":"pause"}   (pause, play, next, previous, stop)
ACTION: {"type":"open_app","name":"YouTube"}   (ऐप का नाम अंग्रेज़ी में)
ACTION: {"type":"flashlight","on":true}
ACTION: {"type":"volume","dir":"up"}   (up, down, mute, max) या {"type":"volume","level":40}
ACTION: {"type":"maps","query":"जगह का नाम"}
ACTION: {"type":"settings","page":"wifi"}   (wifi, bluetooth, airplane, location, display, sound, battery)
ACTION: {"type":"calendar","days":1}   (कैलेंडर के कार्यक्रम पढ़ना)
ACTION: {"type":"notifications"}   (हाल के नोटिफ़िकेशन पढ़ना)
ACTION: {"type":"navigate","where":"back"}   (back, home, recents, notifications, quick_settings, lock, screenshot)
ACTION: {"type":"click","text":"स्क्रीन पर दिखता शब्द"}
ACTION: {"type":"scroll","dir":"down"}   (down या up)
ACTION: {"type":"type","text":"लिखने वाला टेक्स्ट"}
ACTION: {"type":"forget"}   (पुरानी बातचीत भूलना)
ACTION: {"type":"note_add","text":"दूध लाना","list":"शॉपिंग"}   (नोट/लिस्ट में जोड़ना; note_read और note_clear में सिर्फ़ list दो)
ACTION: {"type":"remember","fact":"यूज़र का जन्मदिन 5 मई है"}   (हमेशा के लिए याद रखना)
ACTION: {"type":"notifications","app":"WhatsApp"}   (नए मैसेज पढ़ना; app वैकल्पिक है)
ACTION: {"type":"look","source":"screen","question":"स्क्रीन पर क्या लिखा है?"}   (तस्वीर देखकर जवाब: source = screen (फ़ोन की स्क्रीन), front (सामने का सेल्फ़ी कैमरा, यूज़र को देखने के लिए), back (पीछे का कैमरा); question में यूज़र का सवाल)
वाई-फ़ाई या ब्लूटूथ चालू-बंद करने के लिए पहले navigate quick_settings, फिर click में उसका नाम (Wi-Fi या Bluetooth) दो।
नाम, नंबर या मैसेज कभी खुद मत गढ़ो। मैसेज का टेक्स्ट यूज़र के बोले शब्दों में रखो।
पिछली बातचीत याद रखो।
""".trimIndent()
    }

    private fun buildBody(contents: JSONArray, system: String, thinking: Boolean, search: Boolean): JSONObject {
        val b = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(
                JSONObject().put("text", system))))
            .put("contents", contents)
        if (search) b.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        if (thinking) b.put("generationConfig", JSONObject().put("thinkingConfig",
            JSONObject().put("thinkingLevel", thinkLevel)))
        return b
    }

    /** जवाब की SSE स्ट्रीम पढ़ता है और हर पूरी लाइन आते ही onLine को देता है */
    private fun streamGemini(url: String, key: String, body: JSONObject,
                             onLine: (String) -> Unit): Pair<Int, String> {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
            doOutput = true; connectTimeout = 15000; readTimeout = 45000
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        if (code !in 200..299)
            return Pair(code, conn.errorStream?.bufferedReader()?.readText() ?: "")

        val buf = StringBuilder()
        conn.inputStream.bufferedReader().useLines { lines ->
            for (ln in lines) {
                if (!ln.startsWith("data:")) continue
                val js = ln.removePrefix("data:").trim()
                if (js.isEmpty() || js == "[DONE]") continue
                val chunk = try { JSONObject(js) } catch (e: Exception) { continue }
                val parts = chunk.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (i in 0 until parts.length()) buf.append(parts.getJSONObject(i).optString("text", ""))
                while (true) {
                    val nl = buf.indexOf("\n")
                    if (nl < 0) break
                    onLine(buf.substring(0, nl))
                    buf.delete(0, nl + 1)
                }
            }
        }
        if (buf.isNotBlank()) onLine(buf.toString())
        return Pair(code, "")
    }

    private fun processAudio(pcm: ByteArray) {
        val cfg = getSharedPreferences("settings", MODE_PRIVATE)
        val key = cfg.getString("api_key", "")?.trim().orEmpty()
        if (key.isEmpty()) { say("पहले ऐप की सेटिंग में API key डालें"); return }
        val model = cfg.getString("model", DEFAULT_MODEL)?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }
        val city = cfg.getString("city", "")?.trim().orEmpty()
        val nick = cfg.getString("nick", "")?.trim().orEmpty().ifEmpty { "भाई" }
        val ambient = cfg.getBoolean("ambient", true)
        val wake = false   // अब "धाकड़" बोलना ज़रूरी नहीं
        val useSearch = cfg.getBoolean("use_search", true)
        thinkLevel = if (cfg.getBoolean("think", false)) "LOW" else "MINIMAL"
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"

        // जवाब की हालत (स्ट्रीम की लाइनें आते-आते भरती है)
        var heard = ""
        var first = true
        var none = false
        var suppress = false
        var spokeAny = false
        var ambientMode = false
        var ambientSpoke = false
        var ambientHeard = ""
        var needLive = false
        var pass = 1
        val ownerCheck = ownerNeeded()
        var fired = 0
        val actions = ArrayList<JSONObject>()
        val replyAcc = StringBuilder()

        fun onLine(raw: String) {
            val t = raw.trim()
            if (t.isEmpty() || t.startsWith("```")) return
            if (tagOf(t, "मालिक") != null) {                 // कैमरे से मालिक की जाँच का नतीजा
                first = false
                if (t.contains("हाँ") || t.contains("हां")) {
                    ownerAuthUntil = System.currentTimeMillis() + 90_000
                    setStatus("मालिक पहचाना ✅")
                    first = true                           // अगली लाइन (सुना:/आसपास:/NONE) पहली मानो
                } else {
                    suppress = true
                    val nowT = System.currentTimeMillis()
                    if (t.contains("अनजान") && nowT - lastDenyAt > 60_000) {
                        lastDenyAt = nowT
                        say("माफ़ कीजिए, मैं सिर्फ़ अपने बॉस की बात मानता हूँ")
                    } else listenSoon()
                }
                return
            }
            if (first) {
                first = false
                if (t.startsWith("NONE")) { none = true; return }
                if (tagOf(t, "आसपास") != null) {            // आसपास की आवाज़, यूज़र की नहीं
                    ambientMode = true
                    ambientHeard = tagOf(t, "आसपास").orEmpty().trim()
                    setStatus("आसपास सुना: " + ambientHeard.take(60))
                    return
                }
                if (tagOf(t, "सुना") != null) {
                    heard = tagOf(t, "सुना").orEmpty().trim()
                    if (heard.isNotEmpty()) setStatus("सुना: $heard")
                    val h = heard.lowercase()
                    val tokens = h.split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }
                    val p = pending
                    if (p != null) {                     // पहले पूछे गए काम की हाँ/नहीं
                        pending = null
                        if (System.currentTimeMillis() - pendingAt < 30_000) {
                            if (tokens.any { it in NO }) { suppress = true; say("जी, रद्द कर दिया"); return }
                            if (tokens.any { it in YES }) { suppress = true; execute(p, null, false); return }
                        }
                    }
                    if ("भूल जाओ" in h || "याददाश्त मिटाओ" in h) {
                        suppress = true
                        prefs.edit().remove("h").apply()
                        say("सब कुछ भूल गया"); return
                    }
                    return
                }
            }
            if (none || suppress) return
            if (t.equals("NONE", ignoreCase = true)) return
            if (pass == 1 && t.startsWith("LIVE")) {     // ताज़ा जानकारी चाहिए: तुरंत हाँ बोलो, फिर खोजो
                needLive = true
                say("जी, एक सेकंड, देखता हूँ", flush = true)
                spokeAny = true
                return
            }
            if (needLive && pass == 1) return
            if (ambientMode) {
                if (CONTROL_RE.containsMatchIn(t) || t.equals("NONE", ignoreCase = true)) return   // आसपास की आवाज़ से कभी कोई काम नहीं
                val nowT = System.currentTimeMillis()
                if (!ambientSpoke && nowT - lastAmbientAt < AMBIENT_GAP) return   // बार-बार न टोके
                if (ambientSpoke && replyAcc.length > 200) return
                say(t, flush = !ambientSpoke)
                ambientSpoke = true; spokeAny = true; lastAmbientAt = nowT
                replyAcc.append(t).append(' ')
                return
            }
            val actionJson = tagOf(t, "ACTION")
            if (actionJson != null) {
                val a = try { JSONObject(actionJson.trim()) } catch (_: Exception) { null }
                if (a != null) {
                    if (a.optString("type") == "look") {
                        submitLook(a); fired++               // तस्वीर लेकर देखना
                    } else {
                        actions.add(a)
                        if (!runner.needsConfirm(a) && a.optString("type") != "forget") {
                            submitAction(a)                  // पूरे जवाब का इंतज़ार नहीं, काम तुरंत
                            fired++
                        }
                    }
                }
                return
            }
            if (CONTROL_RE.containsMatchIn(t)) return    // कंट्रोल वाली लाइन कभी बोलकर न सुनाओ
            say(t, flush = !spokeAny)                    // पूरा जवाब आने का इंतज़ार नहीं, तुरंत बोलो
            spokeAny = true
            replyAcc.append(t).append(' ')
        }

        fun historyContents(): JSONArray {
            val c = JSONArray()
            val hist = loadHistory()
            for (i in maxOf(0, hist.length() - 12) until hist.length()) c.put(hist.getJSONObject(i))
            return c
        }

        // कोशिशें: (सोचना-कम, सर्च) -> (बिना सोचना-सेटिंग) -> (बिना सर्च)
        fun callWithFallback(contents: JSONArray, system: String, search: Boolean): Pair<Int, String> {
            val variants = ArrayList<Pair<Boolean, Boolean>>()
            variants.add(Pair(useThinking, search))
            if (useThinking) variants.add(Pair(false, search))
            if (search) variants.add(Pair(false, false))
            var code = 0
            var err = ""
            for (v in variants) {
                val r = streamGemini(url, key, buildBody(contents, system, v.first, v.second)) { onLine(it) }
                code = r.first; err = r.second
                if (code in 200..299) break
                if (code == 400 && v.first) useThinking = false
                if (code != 400 && code != 429) break
            }
            if (code == 429) {                           // थोड़ा रुककर एक बार और
                Thread.sleep(2000)
                val v = variants.last()
                val r = streamGemini(url, key, buildBody(contents, system, v.first, v.second)) { onLine(it) }
                code = r.first; err = r.second
            }
            return Pair(code, err)
        }

        try {
            val contents = historyContents()
            val parts = JSONArray()
            if (ownerCheck) {                                // मालिक की पहचान के लिए दो तस्वीरें जोड़ो
                if (System.currentTimeMillis() - frameJobAt > 15_000) startFrameCapture()
                val deadline = System.currentTimeMillis() + 4000
                while (liveFrameAt < frameJobAt && System.currentTimeMillis() < deadline) Thread.sleep(100)
                val lj = liveFrame
                val orf = try { ownerFile.readBytes() } catch (e: Exception) { null }
                if (lj == null || orf == null || System.currentTimeMillis() - liveFrameAt > 20_000) {
                    setStatus("कैमरे से पहचान नहीं हो सकी, कमांड अनदेखी")   // सुरक्षा: बिना पहचान काम नहीं
                    listenSoon(); return
                }
                parts.put(JSONObject().put("text", "इमेज 1: मालिक की रेफ़रेंस फ़ोटो।"))
                parts.put(imgPart(orf))
                parts.put(JSONObject().put("text", "इमेज 2: अभी की फ्रंट-कैमरा फ़्रेम।"))
                parts.put(imgPart(lj))
            }
            parts.put(JSONObject().put("inline_data", JSONObject()
                .put("mime_type", "audio/wav")
                .put("data", Base64.encodeToString(wav(boost(pcm)), Base64.NO_WRAP))))
            contents.put(JSONObject().put("role", "user").put("parts", parts))

            // पहला पास: तेज़ (बिना सर्च)। ज़्यादातर कमांड और बातचीत यहीं निपट जाती है
            var (code, err) = callWithFallback(
                contents, systemPrompt(city, wake, System.currentTimeMillis() < awakeUntil, useSearch, nick, ambient, owner = ownerCheck), false)

            // दूसरा पास: सिर्फ़ तब जब ताज़ा जानकारी चाहिए (सिर्फ़ टेक्स्ट भेजते हैं, इसलिए तेज़)
            if (code in 200..299 && needLive && heard.isNotEmpty() && !suppress && !none) {
                pass = 2
                val c2 = historyContents()
                c2.put(JSONObject().put("role", "user").put("parts", JSONArray().put(
                    JSONObject().put("text", heard))))
                val r2 = callWithFallback(
                    c2, systemPrompt(city, wake, false, true, nick, false, live = true), true)
                code = r2.first; err = r2.second
            }

            if (code !in 200..299) {
                setStatus("Gemini एरर $code: " + apiMessage(err))
                if (code == 429) {
                    blockedUntil = System.currentTimeMillis() + 60_000
                    say("Gemini की लिमिट पूरी हो गई है। एक मिनट रुककर बोलिए। बार-बार हो तो AI Studio में कोटा देखें।")
                } else say("जवाब नहीं मिल पाया, एरर कोड $code")
                return
            }
        } catch (e: Exception) {
            if (!spokeAny && fired == 0) {
                setStatus("एरर: ${e.javaClass.simpleName}")
                say("जवाब नहीं मिल पाया, इंटरनेट चेक करें")
                return
            }
        }

        // ---- स्ट्रीम पूरी, अब बचे हुए काम ----
        if (none) { listenSoon(); return }
        if (suppress) return
        if (ambientMode) {
            if (!ambientSpoke) listenSoon()
            return
        }
        if (heard.isEmpty() && !spokeAny && actions.isEmpty()) { listenSoon(); return }

        saveTurn(heard.ifEmpty { "(आवाज़)" }, replyAcc.toString().trim().ifEmpty { "(काम किया)" })
        extendWindow = true
        if (actions.any { it.optString("type") == "forget" }) prefs.edit().remove("h").apply()

        val ask = actions.filter { runner.needsConfirm(it) }
        if (ask.isNotEmpty()) {                          // सुरक्षा: भेजने/कॉल से पहले पूछो
            pending = ask; pendingAt = System.currentTimeMillis()
            say(runner.describe(ask[0]), flush = false)
            return
        }
        if (fired == 0 && !spokeAny) listenSoon()
        // वरना: बोलना/काम ख़त्म होते ही अपने-आप सुनना शुरू
    }

    /** काम चलाओ। reply देने पर उसे भी बोलता है; spoke = जवाब पहले ही बोला जा चुका */
    private fun execute(list: List<JSONObject>, reply: String?, spoke: Boolean) {
        if (!reply.isNullOrEmpty()) say(reply)
        if (list.isEmpty()) {
            if (reply.isNullOrEmpty() && !spoke) listenSoon()
            return
        }
        working = true
        thread(priority = Thread.MIN_PRIORITY) {
            val results = ArrayList<String>()
            for (a in list) {
                runner.run(a)?.let { results.add(it) }
                Thread.sleep(500)
            }
            if (results.isNotEmpty()) say(results.joinToString(". "), flush = false)
            else if (reply.isNullOrEmpty() && !spoke) say("हो गया", flush = false)
            working = false
            handler.post { listenSoon() }
        }
    }

    override fun onDestroy() {
        running = false
        instance = null
        try { engine?.release() } catch (_: Exception) { }
        handler.removeCallbacksAndMessages(null)
        actionExec.shutdownNow()
        try { tts.shutdown() } catch (_: Exception) {}
        try { wakeLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
