package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import java.io.File
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** ऐप का लोगो: ग्रेडिएंट गोला, माइक और साउंड वेव्स (कोड से बना, कोई इमेज फ़ाइल नहीं चाहिए) */
class LogoView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2; val r = minOf(w, h) / 2
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, 0xFF7C4DFF.toInt(), 0xFF00E5FF.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 0.95f, p)
        p.shader = null
        p.color = Color.WHITE
        val mw = r * 0.26f
        c.drawRoundRect(cx - mw, cy - r * 0.55f, cx + mw, cy + r * 0.08f, mw, mw, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.09f
        c.drawArc(cx - r * 0.42f, cy - r * 0.38f, cx + r * 0.42f, cy + r * 0.42f, 20f, 140f, false, p)
        c.drawLine(cx, cy + r * 0.42f, cx, cy + r * 0.62f, p)
        c.drawLine(cx - r * 0.2f, cy + r * 0.62f, cx + r * 0.2f, cy + r * 0.62f, p)
        p.alpha = 150
        val wave = RectF(cx - r * 0.78f, cy - r * 0.55f, cx + r * 0.78f, cy + r * 0.3f)
        c.drawArc(wave, -40f, 80f, false, p)
        c.drawArc(wave, 140f, 80f, false, p)
        p.alpha = 255
    }
}

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val sp by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    private lateinit var homeScroll: ScrollView
    private lateinit var settingsScroll: ScrollView
    private lateinit var mainBtn: Button
    private lateinit var status: TextView
    private lateinit var a11y: TextView
    private var ownerRefresh: (() -> Unit)? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int = 28, stroke: Int? = null) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat(); setColor(color)
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(s: String, fill: Int, stroke: Int? = null, onClick: () -> Unit) =
        Button(this).apply {
            text = s; setTextColor(Color.WHITE); isAllCaps = false; textSize = 16f
            background = shape(fill, 28, stroke)
            setOnClickListener { onClick() }
        }

    private fun field(hint: String, value: String, secret: Boolean) = EditText(this).apply {
        this.hint = hint; setText(value); setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = shape(0x22FFFFFF, 16, 0x33FFFFFF)
        isSingleLine = true
        inputType = InputType.TYPE_CLASS_TEXT or
            (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
    }

    private fun lp(top: Int = 0, w: Int = MATCH, h: Int = WRAP) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(24), dp(48), dp(24), dp(24))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F0C29.toInt(), 0xFF302B63.toInt(), 0xFF24243E.toInt()))
        }
        homeScroll = ScrollView(this).apply { addView(buildHome()) }
        settingsScroll = ScrollView(this).apply { addView(buildSettings()); visibility = View.GONE }
        root.addView(homeScroll); root.addView(settingsScroll)
        setContentView(root)
        refresh()
    }

    // ---------- होम स्क्रीन ----------
    private fun buildHome(): View = column().apply {
        addView(LogoView(context), lp(0, dp(120), dp(120)))
        addView(label("Karan assistant", 28f, bold = true), lp(16))
        addView(label("बस बोलिए, मैं सुन रहा हूँ", 15f, 0xFFB8B8D8.toInt()), lp(4))

        status = label("", 14f, 0xFF00E5FF.toInt())
        addView(status, lp(28))
        a11y = label("", 13f, 0xFFB8B8D8.toInt())
        addView(a11y, lp(6))

        mainBtn = button("", 0xFF7C4DFF.toInt()) { toggle() }
        addView(mainBtn, lp(12, MATCH, dp(64)))

        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            background = shape(0x22FFFFFF, 20, 0x22FFFFFF)
            addView(label("मैं क्या कर सकता हूँ", 14f, Color.WHITE, true))
            addView(label("⏰ अलार्म, टाइमर   📞 कॉल, SMS, व्हाट्सऐप\n🌦 मौसम और लाइव खबरें   🎵 गाने\n📇 कॉन्टैक्ट, कैलेंडर, नोटिफ़िकेशन\n🔦 टॉर्च, वॉल्यूम, ऐप खोलना\n♿ फ़ोन कंट्रोल (एक्सेसिबिलिटी)   🧠 याददाश्त", 14f,
                0xFFD0D0E8.toInt()), lp(10))
        }, lp(28))

        addView(button("⚙  सेटिंग (API)", 0x22FFFFFF, 0x55FFFFFF) { showSettings(true) },
            lp(20, MATCH, dp(52)))
        addView(button("🎮  ऐप खोलने की परमिशन (Overlay)", 0x11FFFFFF, 0x33FFFFFF) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lp(10, MATCH, dp(52)))

        addView(button("♿  एक्सेसिबिलिटी चालू करें (फ़ोन कंट्रोल)", 0x22FFFFFF, 0x55FFFFFF) {
            Toast.makeText(context, "सूची में \"Karan assistant\" चुनकर चालू करें", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp(10, MATCH, dp(52)))
        addView(button("🔐  सारी परमिशन दें (कॉन्टैक्ट, SMS, कॉल, कैलेंडर)", 0x22FFFFFF, 0x55FFFFFF) {
            askAll()
        }, lp(10, MATCH, dp(52)))
        addView(button("🔋  बैकग्राउंड में चलने दें (Battery)", 0x11FFFFFF, 0x33FFFFFF) {
            val pm = getSystemService(PowerManager::class.java)
            if (pm.isIgnoringBatteryOptimizations(packageName))
                Toast.makeText(context, "पहले से चालू है ✅", Toast.LENGTH_SHORT).show()
            else startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")))
        }, lp(10, MATCH, dp(52)))

        addView(label("बनाने वाले: धाकड़ 💪", 13f, 0xFF9A9AC0.toInt(), true), lp(36))
    }

    // ---------- सेटिंग स्क्रीन ----------
    private fun buildSettings(): View = column().apply {
        addView(label("⚙  सेटिंग", 24f, bold = true))
        addView(label("Gemini API", 13f, 0xFFB8B8D8.toInt()), lp(4))

        addView(label("API Key", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(28))
        val keyEt = field("यहाँ अपनी API key पेस्ट करें", sp.getString("api_key", "") ?: "", true)
        addView(keyEt, lp(6))

        addView(label("मॉडल", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(18))
        val modelEt = field("gemini-3.5-flash-lite",
            sp.getString("model", AssistantService.DEFAULT_MODEL) ?: AssistantService.DEFAULT_MODEL, false)
        addView(modelEt, lp(6))

        addView(label("आपका शहर (मौसम के लिए)", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(18))
        val cityEt = field("जैसे: Indore", sp.getString("city", "") ?: "", false)
        addView(cityEt, lp(6))

        addView(label("मैं आपको क्या कहकर बुलाऊँ", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(18))
        val nickEt = field("जैसे: भाई, बॉस, करण", sp.getString("nick", "") ?: "", false)
        addView(nickEt, lp(6))

        val searchSw = Switch(context).apply {
            text = "लाइव जानकारी (Google Search)"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("use_search", true)
        }
        addView(searchSw, lp(18))
        addView(label("लिमिट (429) की दिक्कत हो तो इसे बंद कर दें", 12f, 0xFF9A9AC0.toInt()), lp(4))

        val ambientSw = Switch(context).apply {
            text = "आसपास की आवाज़ें सुनकर राय दो"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("ambient", true)
        }
        addView(ambientSw, lp(18))
        addView(label("टीवी या लोगों की बातें सुनकर कभी-कभी (मिनट में एक बार से ज़्यादा नहीं) छोटी राय देगा। इसमें ज़्यादा API इस्तेमाल होता है, और आसपास की आवाज़ Google को जाती है। निजी जगह पर चालू रखें।",
            12f, 0xFF9A9AC0.toInt()), lp(4))


        val loudSw = Switch(context).apply {
            text = "जवाब की आवाज़ तेज़ रखें"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("loud", true)
        }
        addView(loudSw, lp(18))
        addView(label("बोलते समय मीडिया वॉल्यूम कम हो तो उसे 90% तक बढ़ा देगा।", 12f, 0xFF9A9AC0.toInt()), lp(4))

        val thinkSw = Switch(context).apply {
            text = "ज़्यादा सोच-समझकर जवाब दो"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("think", false)
        }
        addView(thinkSw, lp(18))
        addView(label("चालू करने पर जवाब थोड़े गहरे और सटीक होते हैं, पर 1-2 सेकंड ज़्यादा लग सकते हैं।", 12f, 0xFF9A9AC0.toInt()), lp(4))

        addView(label("🎙  लाइव मोड (ChatGPT जैसी असली बातचीत)", 14f, Color.WHITE, true).apply { gravity = Gravity.START }, lp(28))
        val liveSw = Switch(context).apply {
            text = "लाइव मोड चालू (लगातार बातचीत, बीच में टोक सकते हैं)"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("live_mode", true)
        }
        addView(liveSw, lp(10))
        addView(label("लाइव में आपकी आवाज़ लगातार Google के Gemini Live को जाती है और इसमें ज़्यादा API खर्च होता है। सेटिंग बदलने के बाद \"बंद करें\" और \"सुनना शुरू करें\" दोबारा दबाएँ।",
            12f, 0xFF9A9AC0.toInt()), lp(4))
        val bargeSw = Switch(context).apply {
            text = "बीच में टोकना चालू"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("barge", true)
        }
        addView(bargeSw, lp(14))
        addView(label("स्पीकर पर गूँज हो या अपनी ही बात पर जवाब आए तो इसे बंद करें, या इयरफ़ोन लगाएँ।", 12f, 0xFF9A9AC0.toInt()), lp(4))
        addView(label("आवाज़ का नाम (Kore, Puck, Aoede, Charon, Fenrir, Leda, Orus, Zephyr)", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(14))
        val voiceEt = field("Kore", sp.getString("live_voice", "") ?: "", false)
        addView(voiceEt, lp(6))
        addView(label("लाइव मॉडल (खाली छोड़ें तो अपने-आप चुनेगा)", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(14))
        val liveModelEt = field("अपने-आप", sp.getString("live_model", "") ?: "", false)
        addView(liveModelEt, lp(6))
        val liveOut = TextView(context).apply {
            setTextColor(0xFFD0D0E8.toInt()); textSize = 12f; setTextIsSelectable(true)
        }
        addView(button("🧪  Live टेस्ट करें (पहले सेव करें)", 0x22FFFFFF, 0x55FFFFFF) { runLiveTest(liveOut) },
            lp(12, MATCH, dp(52)))
        addView(liveOut, lp(8))

        addView(label("🎮  गेम अपने-आप पहचानना", 14f, Color.WHITE, true).apply { gravity = Gravity.START }, lp(28))
        val gameSw = Switch(context).apply {
            text = "गेम खुलते ही सुनना अपने-आप रोको"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("auto_game", true)
        }
        addView(gameSw, lp(10))
        addView(button("📊  Usage access चालू करें (इसके बिना गेम नहीं पहचानेगा)", 0x22FFFFFF, 0x55FFFFFF) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }, lp(10, MATCH, dp(52)))

        addView(label("☀  सुबह की ब्रीफ़िंग", 14f, Color.WHITE, true).apply { gravity = Gravity.START }, lp(28))
        val briefEt = field("समय, जैसे 07:30 (खाली = बंद)", sp.getString("brief_time", "") ?: "", false)
        addView(briefEt, lp(10))
        addView(label("तय समय पर मौसम, खबरें और कैलेंडर बोलकर सुनाएगा। इसके लिए ऐप उस समय \"सुनना शुरू करें\" हालत में चालू होना चाहिए।",
            12f, 0xFF9A9AC0.toInt()), lp(4))

        addView(label("👤  मालिक की पहचान (कैमरे से)", 14f, Color.WHITE, true).apply { gravity = Gravity.START }, lp(28))
        val ownerStatus = label("", 12f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }
        fun refreshOwner() {
            ownerStatus.text = if (File(filesDir, "owner.jpg").exists()) "मालिक की फ़ोटो: सेव है ✅"
            else "मालिक की फ़ोटो: अभी नहीं है"
        }
        refreshOwner()
        ownerRefresh = { refreshOwner() }
        addView(ownerStatus, lp(6))
        addView(button("🖼  गैलरी से मालिक की फ़ोटो चुनें", 0x22FFFFFF, 0x55FFFFFF) {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
        }, lp(10, MATCH, dp(52)))
        addView(button("📸  सेल्फ़ी से मालिक बनाएँ", 0x22FFFFFF, 0x55FFFFFF) { takeOwnerSelfie() },
            lp(10, MATCH, dp(52)))
        addView(button("🗑  मालिक की फ़ोटो मिटाएँ", 0x11FFFFFF, 0x33FFFFFF) {
            File(filesDir, "owner.jpg").delete(); refreshOwner()
        }, lp(10, MATCH, dp(52)))
        val ownerSw = Switch(context).apply {
            text = "सिर्फ़ मालिक की बात मानो (कैमरे से पहचान)"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("owner_only", false)
        }
        addView(ownerSw, lp(18))
        addView(label("पहचान Gemini AI करता है। यह फ़ोन के फ़ेस-अनलॉक जैसी पक्की सुरक्षा नहीं है, फ़ोटो दिखाकर धोखा दिया जा सकता है। सिर्फ़ अपनी (या जिसकी सहमति हो उसकी) फ़ोटो रखें। फ़ोटो फ़ोन में ही रहती है, पर पहचान के समय Google को भेजी जाती है। पहचान होने के बाद 90 सेकंड तक दोबारा कैमरा नहीं चलता।",
            12f, 0xFF9A9AC0.toInt()), lp(4))

        addView(button("💾  सेव करें", 0xFF7C4DFF.toInt()) {
            sp.edit()
                .putString("api_key", keyEt.text.toString().trim())
                .putString("city", cityEt.text.toString().trim())
                .putString("nick", nickEt.text.toString().trim())
                .putBoolean("use_search", searchSw.isChecked)
                .putBoolean("ambient", ambientSw.isChecked)
                .putBoolean("loud", loudSw.isChecked)
                .putBoolean("think", thinkSw.isChecked)
                .putBoolean("live_mode", liveSw.isChecked)
                .putBoolean("barge", bargeSw.isChecked)
                .putString("live_voice", voiceEt.text.toString().trim())
                .putString("live_model", liveModelEt.text.toString().trim())
                .putBoolean("auto_game", gameSw.isChecked)
                .putString("brief_time", briefEt.text.toString().trim())
                .putBoolean("owner_only", ownerSw.isChecked)
                .putString("model", modelEt.text.toString().trim()
                    .ifEmpty { AssistantService.DEFAULT_MODEL })
                .apply()
            BriefingReceiver.schedule(context)
            Toast.makeText(context, "सेव हो गया ✅", Toast.LENGTH_SHORT).show()
        }, lp(24, MATCH, dp(56)))

        val testOut = TextView(context).apply {
            setTextColor(0xFFD0D0E8.toInt()); textSize = 12f; setTextIsSelectable(true)
        }
        addView(button("🧪  API टेस्ट करें (कौन सा मॉडल चलता है)", 0x22FFFFFF, 0x55FFFFFF) {
            runApiTest(keyEt.text.toString().trim(), modelEt, testOut)
        }, lp(12, MATCH, dp(52)))
        addView(testOut, lp(8))

        addView(button("🔑  API key कहाँ से लें", 0x22FFFFFF, 0x55FFFFFF) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        }, lp(12, MATCH, dp(52)))

        addView(button("🧹  याददाश्त मिटाएँ", 0x22FFFFFF, 0x55FFFFFF) {
            getSharedPreferences("mem", MODE_PRIVATE).edit().remove("h").apply()
            Toast.makeText(context, "पुरानी बातचीत मिट गई", Toast.LENGTH_SHORT).show()
        }, lp(12, MATCH, dp(52)))

        addView(button("← वापस", 0x11FFFFFF, 0x33FFFFFF) { showSettings(false) },
            lp(12, MATCH, dp(52)))

        addView(label("बनाने वाले: धाकड़ 💪", 13f, 0xFF9A9AC0.toInt(), true), lp(36))
    }

    private fun showSettings(show: Boolean) {
        settingsScroll.visibility = if (show) View.VISIBLE else View.GONE
        homeScroll.visibility = if (show) View.GONE else View.VISIBLE
    }

    override fun onBackPressed() {
        if (settingsScroll.visibility == View.VISIBLE) showSettings(false) else super.onBackPressed()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun runLiveTest(out: TextView) {
        out.text = "जाँच चल रही है…"
        Thread {
            val r = try { LiveEngine.test(this) } catch (e: Exception) { "एरर: ${e.javaClass.simpleName}" }
            runOnUiThread { out.text = r }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw Exception("खाली")
                File(filesDir, "owner.jpg").writeBytes(CameraGrab.upright(bytes))
                runOnUiThread {
                    ownerRefresh?.invoke()
                    Toast.makeText(this, "मालिक की फ़ोटो सेव हो गई ✅", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "फ़ोटो नहीं खुल पाई", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun takeOwnerSelfie() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 3)
            Toast.makeText(this, "कैमरे की इजाज़त देकर फिर से दबाएँ", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "कैमरे की तरफ़ सीधे देखिए…", Toast.LENGTH_LONG).show()
        Thread {
            val j = CameraGrab.capture(this, true)
            runOnUiThread {
                if (j != null) {
                    File(filesDir, "owner.jpg").writeBytes(j)
                    ownerRefresh?.invoke()
                    Toast.makeText(this, "सेल्फ़ी से मालिक बन गया ✅", Toast.LENGTH_LONG).show()
                } else Toast.makeText(this, "कैमरा नहीं खुल पाया", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    /** key से कई मॉडल आज़माकर दिखाता है कि कौन सा चलता है, और पहला चलने वाला सेट कर देता है */
    private fun runApiTest(key: String, modelEt: EditText, out: TextView) {
        if (key.isEmpty()) {
            Toast.makeText(this, "पहले API key डालें", Toast.LENGTH_SHORT).show(); return
        }
        out.text = "जाँच चल रही है…"
        Thread {
            val models = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite",
                "gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-3.8-flash")
            val sb = StringBuilder()
            var firstOk: String? = null
            for (m in models) {
                try {
                    val conn = (java.net.URL(
                        "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                        .openConnection() as java.net.HttpURLConnection).apply {
                        requestMethod = "POST"; doOutput = true
                        connectTimeout = 15000; readTimeout = 30000
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("x-goog-api-key", key)
                    }
                    conn.outputStream.use {
                        it.write("""{"contents":[{"parts":[{"text":"hi"}]}]}""".toByteArray())
                    }
                    val code = conn.responseCode
                    val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                        ?.bufferedReader()?.readText() ?: ""
                    if (code in 200..299) {
                        sb.append("✅ $m: चल रहा है\n")
                        if (firstOk == null) firstOk = m
                    } else {
                        val msg = try {
                            org.json.JSONObject(body).getJSONObject("error").getString("message").take(160)
                        } catch (e: Exception) { "" }
                        sb.append("❌ $m: $code $msg\n")
                    }
                } catch (e: Exception) {
                    sb.append("❌ $m: ${e.javaClass.simpleName}\n")
                }
            }
            runOnUiThread {
                if (firstOk != null) {
                    sp.edit().putString("model", firstOk).apply()
                    modelEt.setText(firstOk)
                    sb.append("\nमॉडल अपने-आप '$firstOk' सेट हो गया। अब सुनना शुरू करें।")
                } else {
                    sb.append("\nकोई मॉडल नहीं चला। यह फ्री-टियर की रोक लगती है, AI Studio में बिलिंग चालू करें।")
                }
                out.text = sb.toString()
            }
        }.start()
    }

    private fun askAll() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.READ_CALENDAR,
            Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(p.toTypedArray(), 2)
    }

    // ---------- चालू / बंद ----------
    private fun refresh() {
        val on = sp.getBoolean("running", false)
        mainBtn.text = if (on) "⏹  बंद करें" else "🎤  सुनना शुरू करें"
        mainBtn.background = shape(if (on) 0xFFE53935.toInt() else 0xFF7C4DFF.toInt(), 32)
        status.text = if (on) "● असिस्टेंट सुन रहा है" else "○ असिस्टेंट बंद है"
        a11y.text = if (PhoneControlService.instance != null) "♿ एक्सेसिबिलिटी: चालू ✅"
        else "♿ एक्सेसिबिलिटी: बंद (फ़ोन कंट्रोल के लिए चालू करें)"
    }

    private fun toggle() {
        if (sp.getBoolean("running", false)) {
            stopService(Intent(this, AssistantService::class.java))
            sp.edit().putBoolean("running", false).apply(); refresh(); return
        }
        if (sp.getString("api_key", "").isNullOrBlank()) {
            Toast.makeText(this, "पहले सेटिंग में API key डालें", Toast.LENGTH_LONG).show()
            showSettings(true); return
        }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startAssistant()
        else requestPermissions(perms.toTypedArray(), 1)
    }

    private fun startAssistant() {
        startForegroundService(Intent(this, AssistantService::class.java))
        sp.edit().putBoolean("running", true).apply(); refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code != 1) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startAssistant()
        else Toast.makeText(this, "माइक की परमिशन ज़रूरी है", Toast.LENGTH_LONG).show()
    }
}
